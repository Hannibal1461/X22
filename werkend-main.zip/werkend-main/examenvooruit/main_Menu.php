<?php
function openMenu() {
  echo "<div class='topnav'>
    <a class='btn btn-outline-info' href='view_edit_delete_apparaten.php'>view edit delete apparaten</a><br><br>
    <a class='btn btn-outline-info' href='view_edit_delete_inname.php'>view edit bestellingen</a><br><br>
    <a class='btn btn-outline-info' href='view_edit_delete_innameapparaten.php'>view edit innameapparten</a><br><br>
    <a class='btn btn-outline-info' href='view_edit_delete_onderdeelapparaten.php'>view edit onderdeelapparaten</a><br><br>
    <a class='btn btn-outline-info' href='view_edit_delete_medewerker.php'>view edit medewerker</a><br><br>
    <a class='btn btn-outline-info' href='view_edit_delete_onderdelen.php'>view edit onderdelen</a><br><br>
  </div>";
}
 ?>
