README Kemal examen

er is een database.php document. als je deze database aanmaakt moet je hem ook populaten met populate.sql.
om een admin account aantemaken ga je naar http://localhost/examenvooruit/register.php en maak je een admin acount aan.

zolang er een bestelling is kna je een tafel of gerecht/drinken niet verwijderen.
peace out
