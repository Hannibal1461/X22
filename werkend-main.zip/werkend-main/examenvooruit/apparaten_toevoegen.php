<?php

session_start();
include_once 'main_Menu.php';

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
    header('location: homepagina.php');
    exit;
  }
include 'database.php';
include 'HelperFunctions.php';

if(isset($_POST['submit'])){

  // maak een array met alle name attributes
  $fields = [
    "naam",
    "omschrijving",
    "vergoeding",
    "gewichtgram"
  ];

$obj = new HelperFunctions();
$no_error = $obj->has_provided_input_for_required_fields($fields);

  // in case of field values, proceed, execute insert
  if($no_error){
    $naam = $_POST['naam'];
    $omschrijving = $_POST['omschrijving'];
    $vergoeding = $_POST['vergoeding'];
    $gewichtgram = $_POST['gewichtgram'];


    $db = new database('localhost', 'root', '', 'remas', 'utf8');
    $db->create_apparaten($naam, $omschrijving, $vergoeding, $gewichtgram);

      header('location: apparaten_toevoegen.php');
      exit;
    }
  }
?>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>menu toevoegen</title>
    <style>
        .table-responsive{
            overflow-x: unset !important;
        }
    </style>
  </head>

  <body>
    <div>
      <legend style="text-align: center;"> remas </legend>
      <img src="img\Insert-image-Here.png">
      <a class="btn btn-danger" href="logout.php" style="margin-left:1790px; margin-top:-200px">Logout</a>
      <<?php openMenu(); ?>
      </div>

    <div class="container" style="margin-top:-300px; margin-right:375px;">
      <form method="post" align="center" action='apparaten_toevoegen.php' method='post' accept-charset='UTF-8'>
      <fieldset >
        <legend>menu toevoegen</legend>
        <a class="btn btn-success" href="view_edit_delete_apparaten.php" class="edit_btn" >terug naar menu</a>
        <input type="text" name="naam" placeholder="naam" required/>
        <input type="text" name="omschrijving" placeholder="omschrijving" required/>
        <input type="text" name="vergoeding" placeholder="vergoeding" required/>
        <input type="text" name="gewichtgram" placeholder="gewichtgram" required/>
        <button class="btn btn-outline-success" type="submit" name="submit" value="Sign up!">Register</button>
      </fieldset>
    </form>
  </div>
  </body>
</html>
