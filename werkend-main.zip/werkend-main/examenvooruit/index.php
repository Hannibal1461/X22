<?php
// initialize the session
session_start();

include 'database.php';
include 'helperfunctions.php';

if(isset($_SESSION['loggedin'])){
    header('location: homepagina.php');
    exit;
}
?>

<html>
    <head>
        <title>home</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    </head>
    <div>
      <legend style="text-align: center;"> excellent taste </legend>
      <img src="img\Insert-image-Here.png" width="250" height="250">

      <a class="btn btn-danger" href="login.php" style="margin-left:1680px; margin-top:-200px">inloggen medewerker</a>
      <<?php
      include_once 'main_Menu.php';
      openMenu();
      ?>
        <div align="center">
          <img src="img\Insert-image-Here.png" width="250" height="250">
          <img src="img\Insert-image-Here.png" width="250" height="250">
          <img src="img\Insert-image-Here.png" width="250" height="250">
        </div>
    </body>
</html>
