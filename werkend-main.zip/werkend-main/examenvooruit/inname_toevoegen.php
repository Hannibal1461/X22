<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
    // header('location: homepagina.php');
    // exit;
  }
include 'database.php';
include 'HelperFunctions.php';

if(isset($_POST['submit'])){

  // maak een array met alle name attributes
  $fields = [
    "medewerker_id",
      "tijdstip"
  ];

$obj = new HelperFunctions();
$no_error = $obj->has_provided_input_for_required_fields($fields);

  // in case of field values, proceed, execute insert
  if($no_error){
    $id = $_POST['id'];
    $medewerker_id = $_POST['medewerker_id'];
    $tijdstip = $_POST['tijdstip'];


    $db = new database('localhost', 'root', '', 'remas', 'utf8');
    $db->inname( $medewerker_id , $tijdstip );

      header('location: view_edit_delete_inname.php');
      exit;
    }
  }
?>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>inname</title>
  </head>
  <body>
    <div>
      <legend style="text-align: center;"> remas </legend>
      <img src="img\Insert-image-Here.png">
      <a class="btn btn-danger" href="logout.php" style="margin-left:1790px; margin-top:-200px">Logout</a>
      <<?php
      include_once 'main_Menu.php';
      openMenu();
      ?>
      </div>

      <form method="post" align="center" action='inname_toevoegen.php' method='post' accept-charset='UTF-8' style="margin-top:-350px;">
      <fieldset >
        <legend>reservering</legend>
        <input type="text" name="medewerker_id" placeholder="medewerker_id" required/>
        <input type="date" name="tijdstip" placeholder="tijdstip" required/>
        <button class="btn btn-outline-success" type="submit" name="submit" value="Sign up!">Register</button>
        <a class="btn btn-outline-info" href="view_edit_delete_reservering.php">terug naar reservering</a>
      </fieldset>
    </form>
  </body>
</html>
