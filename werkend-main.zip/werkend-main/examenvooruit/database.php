<?php
//class database aan gemaakt
  class database{
// class met allemaal private variables aangemaakt (property)
  private $host;
  private $db;
  private $user;
  private $pass;
  private $charset;
  private $pdo;

// maakt class constants (admin en user)
// these are the values from the db
const ADMIN = 1;
const MEDEWERKER_INLEVEREN = 2;
const MEDEWERKER_DEMONTAGE   = 3;
const MEDEWERKER_UITGIFTE = 4;
const KLANT = 5;

  public function __construct($host, $user, $pass, $db, $charset){
      $this->host = $host;
      $this->user = $user;
      $this->pass = $pass;
      $this->charset = $charset;

      try {
          $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
          $options = [
              PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
              PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
              PDO::ATTR_EMULATE_PREPARES   => false,
          ];

          $this->pdo = new PDO($dsn, $user, $pass, $options);
      } catch (\PDOException $e) {
          echo $e->getMessage();
          throw $e;
          // throw new \PDOException($e->getMessage(), (int)$e->getCode());
        }
    }

    // kijkt of de account die probeert in te loggen admin is met usertype_id. Als hij een admin is dan word 1 door gestuurt, anders 2.
    private function is_admin($gebruikersnaam){
        // query houd de gegevens in die naar de database gestuurd gaat worden
      $query = "SELECT usertype_id FROM medewerker WHERE gebruikersnaam = :gebruikersnaam";

        // dit voert de query uit
      $stmt = $this->pdo->prepare($query);
      $stmt->execute(['gebruikersnaam'=>$gebruikersnaam]);

      $result = $stmt->fetch();

        // kijkt of usertype_id gelijk is aan admin zo ja dan ben je admin en word je gestuurt naar homepagina.php
      if($result['usertype_id'] == self::ADMIN){
            return true;
      }

        // user is not admin
        return false;
    }

    // Verwijderd users uit de database. Pagina: view_edit_delete_medewerker
    public function deleteUser($id){
        echo $id;
        try{
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("DELETE FROM medewerker WHERE id=:id");
            $stmt->execute(['id'=>$id]);

            $this->pdo->commit();

        }catch(Exception $e){
            $this->pdo->rollback();
            echo 'Error: '.$e->getMessage();
        }
    }

    // wijzigd de gegevens van een account. Pagina: edit_user.php
    public function editUser($id, $usertype_id, $voorletters, $voorvoegsels, $email){
      $query = "  UPDATE
                    medewerker
                  SET
                    usertype_id = :usertype_id,
                    voorletters = :voorletters,
                    voorvoegsels = :voorvoegsels,
                    email = :email
                  WHERE id = :id";

      $statement = $this->pdo->prepare($query);

      $statement->execute([
      'id'=>$id,
      'usertype_id'=>$usertype_id,
      'voorletters'=>$voorletters,
      'voorvoegsels'=>$voorvoegsels,
      'email'=>$email
      ]);

      $medewerker_id = $this->pdo->lastInsertId();
      return $medewerker_id;
    }

    // pakt de account gegevens vanuit de database om het te laten zien in een tabel in pagina: view_edit_delete_medewerker
    public function view_user_detail($gebruikersnaam){

        $query = "SELECT id, usertype_id, voorletters, voorvoegsels, email, gebruikersnaam FROM medewerker

        ";

        if($gebruikersnaam !== NULL){
            // query for specific user when a username is supplied
            $query .= 'WHERE gebruikersnaam = :gebruikersnaam';
        }

        $stmt = $this->pdo->prepare($query);

        // check if username is supplied, if so, pass assoc array to execute
        $gebruikersnaam !== NULL ? $stmt->execute(['gebruikersnaam'=>$gebruikersnaam]) : $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    // maakt een medewerker aan in het database. Pagina: Register.php
    public function create_medewerker($usertype_id, $voorletters, $voorvoegsels, $email, $gebruikersnaam, $wachtwoord){
      $query = "INSERT INTO medewerker
            (id, usertype_id, voorletters, voorvoegsels, email, gebruikersnaam, wachtwoord)
            VALUES
            (NULL, :usertype_id, :voorletters, :voorvoegsels, :email, :gebruikersnaam, :wachtwoord)";

      $statement = $this->pdo->prepare($query);

      // password hashen
      $hashed_password =  password_hash($wachtwoord, PASSWORD_DEFAULT);

      $statement->execute([
        'usertype_id'=>$usertype_id,
        'voorletters'=>$voorletters,
        'voorvoegsels'=>$voorvoegsels,
        'email'=>$email,
        'gebruikersnaam'=>$gebruikersnaam,
        'wachtwoord'=>$hashed_password
      ]);

      // haalt de laatst toegevoegde id op uit de db
      $medewerker_id = $this->pdo->lastInsertId();
      return $medewerker_id;
    }

    // ----------------------------------------------------------------------------------------------------------------------------------

    // verwijderd artikelen die zn ids overeen komen met die gegeven is. Pagina: view_edit_delete_artikelen
    public function deleteApparaten($id){
        try{
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("DELETE FROM apparaten WHERE id=:id");
            $stmt->execute(['id'=>$id]);

            $this->pdo->commit();
        }catch(Exception $e){
            $this->pdo->rollback();
            echo 'Error: '.$e->getMessage();
        }
    }

    // pakt artikel informatie uit de database pagina: view_edit_delete_artikelen
    public function get_apparaten_information($product){

        $query = "SELECT id, naam, omschrijving, vergoeding, gewichtgram FROM apparaten

        ";

        if($product !== NULL){
            // query for specific user when a username is supplied
            $query .= 'WHERE naam = :naam';
        }

        $stmt = $this->pdo->prepare($query);

        // check if username is supplied, if so, pass assoc array to execute
        $product !== NULL ? $stmt->execute(['naam'=>$naam]) : $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    // maakt een artikel aan in het database. Pagina: artikel_toevoegen.php
    public function create_apparaten($naam, $omschrijving, $vergoeding, $gewichtgram){
      $query = "INSERT INTO apparaten
            (id, naam, omschrijving, vergoeding, gewichtgram)
            VALUES
            (NULL, :naam, :omschrijving, :vergoeding, :gewichtgram)";

      $statement = $this->pdo->prepare($query);

      $statement->execute([
        'naam'=>$naam,
        'omschrijving'=>$omschrijving,
        'vergoeding'=>$vergoeding,
        'gewichtgram'=>$gewichtgram
      ]);

      // haalt de laatst toegevoegde id op uit de db
      $medewerker_id = $this->pdo->lastInsertId();
      return $medewerker_id;
    }

    // update de gegevens van een bestaande artikel. Pagina: artikelwijzigen.php
    public function update_apparaten($id, $naam, $omschrijving, $vergoeding, $gewichtgram){
      $query = "UPDATE apparaten
      SET naam = :naam, omschrijving = :omschrijving, vergoeding = :vergoeding, gewichtgram = :gewichtgram
      WHERE id = :id";
      $statement = $this->pdo->prepare($query);
      $statement->execute([
        'id'=>$id,
        'naam'=>$naam,
        'omschrijving'=>$omschrijving,
        'vergoeding'=>$vergoeding,
        'gewichtgram'=>$gewichtgram
      ]);

      // haalt de laatst toegevoegde id op uit de db
      $artikel_id = $this->pdo->lastInsertId();
      return $artikel_id;
    }

    public function onderdelen($naam, $omschrijving, $voorraadkg, $prijsperkg){
      $query = "INSERT INTO onderdelen
            (id, naam, omschrijving, voorraadkg, prijsperkg)
            VALUES
            (NULL, :naam, :omschrijving, :voorraadkg, :prijsperkg)";

      $statement = $this->pdo->prepare($query);

      $statement->execute([
        'naam'=>$naam,
        'omschrijving'=>$omschrijving,
        'voorraadkg'=>$voorraadkg,
        'prijsperkg'=>$prijsperkg
      ]);
    }

    // update de gegevens van een bestaande artikel. Pagina: artikelwijzigen.php
    public function onderdelen_wijzigen($id, $naam, $omschrijving, $voorraadkg, $prijsperkg){
      $query = "UPDATE onderdelen
      SET naam = :naam, omschrijving = :omschrijving, voorraadkg = :voorraadkg, prijsperkg = :prijsperkg
      WHERE id = :id";
      $statement = $this->pdo->prepare($query);
      $statement->execute([
        'id'=>$id,
        'naam'=>$naam,
        'omschrijving'=>$omschrijving,
        'voorraadkg'=>$voorraadkg,
        'prijsperkg'=>$prijsperkg
      ]);

      // haalt de laatst toegevoegde id op uit de db
      $artikel_id = $this->pdo->lastInsertId();
      return $artikel_id;
    }

    // pakt artikel informatie uit de database pagina: view_edit_delete_artikelen
    public function get_onderdelen_information($product){

        $query = "SELECT id, naam, omschrijving, voorraadkg, prijsperkg FROM onderdelen

        ";

        if($product !== NULL){
            // query for specific user when a username is supplied
            $query .= 'WHERE voornaam = :voornaam';
        }

        $stmt = $this->pdo->prepare($query);

        // check if username is supplied, if so, pass assoc array to execute
        $product !== NULL ? $stmt->execute(['product'=>$product]) : $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    // Verwijderd users uit de database. Pagina: view_edit_delete_medewerker
    public function deleteonderdelen($id){
        echo $id;
        try{
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("DELETE FROM onderdelen WHERE id=:id");
            $stmt->execute(['id'=>$id]);

            $this->pdo->commit();

        }catch(Exception $e){
            $this->pdo->rollback();
            echo 'Error: '.$e->getMessage();
        }
    }
// -----

public function inname($medewerker_id, $tijdstip){
  $query = "INSERT INTO inname
        (id, medewerker_id, tijdstip)
        VALUES
        (NULL, :medewerker_id, :tijdstip)";

  $statement = $this->pdo->prepare($query);

  $statement->execute([
    'medewerker_id'=>$medewerker_id,
    'tijdstip'=>$tijdstip
  ]);
}

// update de gegevens van een bestaande artikel. Pagina: artikelwijzigen.php
public function inname_wijzigen($id, $medewerker_id, $tijdstip){
  $query = "UPDATE inname
  SET medewerker_id = :medewerker_id, tijdstip = :tijdstip
  WHERE id = :id";
  $statement = $this->pdo->prepare($query);
  $statement->execute([
    'id'=>$id,
    'medewerker_id'=>$medewerker_id,
    'tijdstip'=>$tijdstip
  ]);

  // haalt de laatst toegevoegde id op uit de db
  $id = $this->pdo->lastInsertId();
  return $id;
}

// pakt artikel informatie uit de database pagina: view_edit_delete_artikelen
public function get_inname_information($product){

    $query = "SELECT id, medewerker_id, tijdstip FROM inname

    ";

    if($product !== NULL){
        // query for specific user when a username is supplied
        $query .= 'WHERE medewerker_id = :medewerker_id';
    }

    $stmt = $this->pdo->prepare($query);

    // check if username is supplied, if so, pass assoc array to execute
    $product !== NULL ? $stmt->execute(['medewerker_id'=>$medewerker_id]) : $stmt->execute();

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $results;
}

// Verwijderd users uit de database. Pagina: view_edit_delete_medewerker
public function deleteinname($id){
    echo $id;
    try{
        $this->pdo->beginTransaction();

        $stmt = $this->pdo->prepare("DELETE FROM inname WHERE id=:id");
        $stmt->execute(['id'=>$id]);

        $this->pdo->commit();

    }catch(Exception $e){
        $this->pdo->rollback();
        echo 'Error: '.$e->getMessage();
    }
}


public function get_onderdeelapparaat_information($product){

  $query = "SELECT id, onderdelen_id, apparaten_id, percentage FROM onderdeelapparaat

  ";


    if($product !== NULL){
        // query for specific user when a username is supplied
        $query .= 'WHERE product = :product';
    }

    $stmt = $this->pdo->prepare($query);

    // check if username is supplied, if so, pass assoc array to execute
    $product !== NULL ? $stmt->execute(['product'=>$product]) : $stmt->execute();

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $results;
}


public function get_innameapparaten_information($product){

    $query = "SELECT id, inname_id, apparaten_id, ontleed FROM innameapparaten

    ";

    if($product !== NULL){
        // query for specific user when a username is supplied
        $query .= 'WHERE product = :product';
    }

    $stmt = $this->pdo->prepare($query);

    // check if username is supplied, if so, pass assoc array to execute
    $product !== NULL ? $stmt->execute(['product'=>$product]) : $stmt->execute();

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $results;
}

// ----------------------------------------------------------------------------------------------------------------------------------
    // bekijkt of de gegevens die zijn ingevuld in login.php kloppen zodat je kunt inloggen.
    public function authenticate_user($gebruikersnaam, $wachtwoord){

          $query = "SELECT wachtwoord
          FROM medewerker
          WHERE gebruikersnaam = :gebruikersnaam";

          $stmt = $this->pdo->prepare($query);
          // voorbereide instructieobject wordt uitgevoerd.
          $stmt->execute(['gebruikersnaam' => $gebruikersnaam]); //-> araay
          $result = $stmt->fetch(); // returned een array

          // checkt of $result een array is
          if(is_array($result)){
          // voerd count uit als #result een array is
          if(count($result) > 0){

          $hashed_password = $result['wachtwoord'];

          if($gebruikersnaam && password_verify($wachtwoord, $hashed_password)){
              // session_start();
              // slaat userdata in sessie veriable
              $_SESSION['gebruikersnaam'] = $gebruikersnaam;
              $_SESSION['usertype'] = $result['usertype_id'];
              $_SESSION['loggedin'] = true;

              if($this->is_admin($gebruikersnaam)){
                  header("location: homepagina.php");
                  //make sure that code below redirect does not get executed when redirected.
                  exit;
              }  // redirect user to the user-page if not admin.
                header("location: welcome_user.php");
                exit;
              }
            }
          }
        }


  }
?>
