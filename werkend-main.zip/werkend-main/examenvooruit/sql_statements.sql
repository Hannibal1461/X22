-- create new db
CREATE DATABASE remas;


-- tabel usertype aanmaken, met dit tabel kun je kijken of iemand een admin is of een medewerker is
CREATE TABLE usertype(
    id INT NOT NULL AUTO_INCREMENT,
    type VARCHAR(255),
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY(id)
);

-- insert entrIES into table usertype (admin AND chef and ober)
INSERT INTO usertype VALUES (NULL, 'ADMIN', now(), now()), (NULL, 'MEDEWERKER_INLEVEREN', now(), now()), (NULL, 'MEDEWERKER_DEMONTAGE', now(), now()), (NULL, 'MEDEWERKER_UITGIFTE', now(), now()), (NULL, 'KLANT', now(), now());

-- tabel Medewerker aanmaken.
CREATE TABLE medewerker(
    id INT NOT NULL AUTO_INCREMENT,
    usertype_id INT NOT NULL,
    voorletters VARCHAR(250) NOT NULL,
    voorvoegsels VARCHAR(250),
    email VARCHAR(250),
    gebruikersnaam VARCHAR(250),
    wachtwoord VARCHAR(250),
    PRIMARY KEY(id),
    FOREIGN KEY(usertype_id) REFERENCES usertype(id)
);

-- tabel tafels aanmaken.
CREATE TABLE apparaten(
    id INT NOT NULL AUTO_INCREMENT,
    naam VARCHAR(40) NOT NULL,
    omschrijving VARCHAR(200) NOT NULL,
    vergoeding INT NOT NULL,
    gewichtgram INT,
    PRIMARY KEY(id)
);

-- tabel bestellingen aanmaken.
CREATE TABLE onderdelen(
    id INT NOT NULL AUTO_INCREMENT,
    naam VARCHAR(40) NOT NULL,
    omschrijving VARCHAR(200) NOT NULL,
    voorraadkg INT NOT NULL,
    prijsperkg INT NOT NULL,
    PRIMARY KEY(id)
);

-- tabel bestellingen aanmaken.
CREATE TABLE inname(
    id INT NOT NULL AUTO_INCREMENT,
    medewerker_id INT NOT NULL,
    tijdstip DATE NOT NULL,
    FOREIGN KEY(medewerker_id) REFERENCES medewerker(id),
    PRIMARY KEY(id)
);

-- tabel menu aanmaken.
CREATE TABLE onderdeelapparaat(
    id INT NOT NULL AUTO_INCREMENT,
    onderdelen_id INT NOT NULL,
    apparaten_id INT NOT NULL,
    percentage INT,
    PRIMARY KEY(id),
    FOREIGN KEY(onderdelen_id) REFERENCES onderdelen(id),
    FOREIGN KEY(apparaten_id) REFERENCES apparaten(id)
);

-- tabel menu aanmaken.
CREATE TABLE innameapparaten(
    id INT NOT NULL AUTO_INCREMENT,
    inname_id INT NOT NULL,
    apparaten_id INT NOT NULL,
    ontleed BOOLEAN NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY(inname_id) REFERENCES inname(id),
    FOREIGN KEY(apparaten_id) REFERENCES apparaten(id)
);

-- tabel menu aanmaken.
CREATE TABLE uitgifters(
    id INT NOT NULL AUTO_INCREMENT,
    medewerker_id INT NOT NULL,
    onderdelen_id INT NOT NULL,
    tijdstip DATETIME NOT NULL,
    gewichtkg INT NOT NULL,
    prijs INT NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY(medewerker_id) REFERENCES medewerker(id),
    FOREIGN KEY(onderdelen_id) REFERENCES onderdelen(id)
);
